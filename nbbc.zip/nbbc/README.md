NBBC
====

New BBCode Parser

Cloned from sourceforge http://nbbc.sourceforge.net/
